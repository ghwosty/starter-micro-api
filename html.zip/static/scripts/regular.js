var localUsername = localStorage.getItem("username");
var socket = io();
var currentEncryptionKey;
var currentRoom;
var currentSendingElement;
_("#settingsMentionUsername").innerText = "@" + localUsername;
// Socket functions

socket.on("joinSuccess", (room) => {
  currentRoom = room;
  _("#roomName").innerText = room;
  setTimeout(() => {
    _("#joiningRoomModal").css("scale", "0")
    _("#shade").hide();
    _(".container", true).forEach(ele => { ele.css("scale", "0"); })
    _("#chatContainer").css("scale", "1");
  }, 500)
})

socket.on("recieve_message", (message, username, isSystem, id) => {
  console.log("recieve message")
  if (document.body.contains(_(`#${id}`))) {
    setTimeout(() => {
      _(`#${id}`).style.opacity = "1";
      currentSendingElement = null;
    }, getRand(100, 400))
  } else {
    const m = document.createElement("div");
    m.classList.add("message");
    m.innerHTML = `
    <span class="messageUsername">${username}</span>
    <br>
    <span class="messageText">${message}</span>
    `
    m.id = id;
    _("#messagesContainer").appendChild(m)
    _("#messagesContainer").scrollBottom();
  }
})

socket.on("recieve_join", (user, online, disconnect) => {
  console.log("recieve join")
  _("#roomConnected").innerText = `${online} Connected`
  if (disconnect) {
    const element = document.createElement("p");
    element.innerHTML = `"${user}" disconnected.`
    element.style.color = "red"
    element.style.fontSize = "17px"
    element.style.fontFamily = "'Lato', serif;"
    _("#messagesContainer").appendChild(element)
  } else {
    const element = document.createElement("p");
    element.innerHTML = `"${user}" connected to the room.`
    element.style.color = "green"
    element.style.fontSize = "17px"
    element.style.fontFamily = "'Lato', serif;"
    _("#messagesContainer").appendChild(element)
  }
})

if (localStorage.getItem("username")) {
  _("#chatRoomJoinOptionsContainer").style.scale = "1";
} else {
  _("#setUsernameContainer").style.scale = "1";
}

_("#confirmbtn1").addEventListener("click", () => {
  // confirm username
})

if (!localStorage.getItem("savedChatrooms")) {
  _("#savedChatroomsContainer").hide();
}

_("#confirmbtn2").addEventListener("click", () => {
  // join room
  const room = _("#chatRoomJoinInput").value;
  if (room.replaceAll(" ", "") == "") {
    _("#crjiL").css("color", "red")
    _("#crjiL").css("font-size", "18px");
    _("#crjiL").innerText = "Room required!"
    setTimeout(() => {
      _("#crjiL").css("font-size", "15px")
    }, 300)
    return;
  }
  postData('/checkRoom', { room: room, user: localUsername })
    .then((data) => {
      if (data.roomEncrypted) {
        // room encypted6
      }
      else {
        _("#joiningRoomModal").css("scale", "1");
        _("#shade").show();
        _("#shade").css("opacity", ".3");
        socket.emit("joinRoom", localUsername, room);
      }
    });
})

_("#chatRoomJoinInput").addEventListener("keydown", (e) => {
  if (e.keyCode === 13) {
    const room = _("#chatRoomJoinInput").value;
    if (room.replaceAll(" ", "") == "") {
      _("#crjiL").css("color", "red")
      _("#crjiL").css("font-size", "18px");
      _("#crjiL").innerText = "Room required!"
      setTimeout(() => {
        _("#crjiL").css("font-size", "15px")
      }, 300)
      return;
    }
    postData('/checkRoom', { room: room, user: localUsername })
      .then((data) => {
        if (data.roomEncrypted) {
          // room encypted6
        }
        else {
          _("#joiningRoomModal").css("scale", "1");
          _("#shade").show();
          _("#shade").css("opacity", ".3");
          socket.emit("joinRoom", localUsername, room);
        }
      });
  }
})

_("#confirmbtn1").addEventListener("click", (e) => {
  if (_("#usernameInput").value.replaceAll(" ", "") == "") return;
  localStorage.setItem("username", _("#usernameInput").value);
  window.location = ''
})

_("#usernameInput").addEventListener("keydown", (e) => {
  if (e.keyCode === 13) {
    if (_("#usernameInput").value.replaceAll(" ", "") == "") return;
    localStorage.setItem("username", _("#usernameInput").value);
    window.location = ''
  }
})

async function postData(url = '', data = {}) {
  const response = await fetch(url, {
    method: 'POST',
    body: JSON.stringify(data),
    headers: {
      'Content-Type': 'application/json'
    },
  });
  return response.json();
}

_("#ccbiInput").addEventListener("keydown", (e) => {
  const input = _("#ccbiInput");
  if (input.attribute("data") == "nonEditied") {
    _("#inputPlaceholder").remove();
    input.innerText = "";
    input.attribute("data", "edited")
  }
  else if (e.keyCode == 8) {
    setTimeout(() => {
      if (_("#ccbiInput").innerText == "") {
        const placeholder = document.createElement("span");
        placeholder.style.opacity = "0.5";
        placeholder.innerText = "Message potato room"
        placeholder.id = "inputPlaceholder"
        _("#ccbiInput").append(placeholder);
        input.attribute("data", "nonEditied")
      }
    }, 200)
  }
  else if (e.keyCode == 13) {
    e.preventDefault();
    if (_("#ccbiInput").innerText.replaceAll(/\s/g, "").replaceAll("\n", "") == "");
    const date = new Date();
    const pe = makeId(21).replaceAll(/[0-9]/g, "")
    const m = document.createElement("div");
    m.classList.add("message");
    m.innerHTML = `
        <span class="messageUsername">${localUsername}</span>
        <br>
        <span class="messageText">${_("#ccbiInput").innerText.sanitize()}</span>
        `
    m.style.opacity = "0.5"
    m.id = pe;
    currentSendingElement = m;
    _("#messagesContainer").appendChild(m)
    _("#messagesContainer").scrollBottom();
    postData("/sendMessage", { user: localUsername, message: _("#ccbiInput").innerText.sanitize(), time: date.getHours() + ":" + date.getMinutes(), isSystem: false, id: pe })
      .then((data) => {
        console.dir(data)
        const placeholder = document.createElement("span");
        placeholder.style.opacity = "0.5";
        placeholder.innerText = "Message potato room"
        placeholder.id = "inputPlaceholder"
        _("#ccbiInput").attribute("data", "nonEditied")
        _("#ccbiInput").innerText = ""
        _("#ccbiInput").append(placeholder);
        if (data.limiter) {
          _("#slowDownModal").css("scale", "1")
          _("#shade").show();
          document.activeElement.blur();
        }
      })
  }
})

_("#sentbutton").addEventListener("click", (e) => {
  if (_("#ccbiInput").innerText.replaceAll(/\s/g, "").replaceAll("\n", "") == "");
  const date = new Date();
  if (_("#ccbiInput").contains(_("#inputPlaceholder"))) return
  const pe = makeId(21).replaceAll(/[0-9]/g, "")
  const m = document.createElement("div");
  m.classList.add("message");
  m.innerHTML = `
      <span class="messageUsername">${localUsername}</span>
      <br>
      <span class="messageText">${_("#ccbiInput").innerText.sanitize()}</span>
      `
  m.style.opacity = "0.5"
  m.id = pe;
  currentSendingElement = m;
  _("#messagesContainer").appendChild(m)
  _("#messagesContainer").scrollBottom();
  postData("/sendMessage", { user: localUsername, message: _("#ccbiInput").innerText.sanitize(), time: date.getHours() + ":" + date.getMinutes(), isSystem: false, id: pe })
    .then((data) => {
      console.dir(data)
      const placeholder = document.createElement("span");
      placeholder.style.opacity = "0.5";
      placeholder.innerText = "Message potato room"
      placeholder.id = "inputPlaceholder"
      _("#ccbiInput").attribute("data", "nonEditied")
      _("#ccbiInput").innerText = ""
      _("#ccbiInput").append(placeholder);
      if (data.limiter) {
        _("#slowDownModal").css("scale", "1")
        _("#shade").show();
        document.activeElement.blur();
      }
    })
})

_("#settingsOpen").addEventListener("click", () => {

})