var inRoom = false;
var socket = io();
var localUsername = localStorage.getItem("username") || "guestuser";
_("#consoleInputUser").innerText = localUsername + ">";
var requireRefresh = false;
var calmDown = false;
var currentEncryptionKey;
var currentRoom = "";
var waitingForKey = false;

// Sockets !!!
socket.on("recieve_message", (message, username, fromSystem) => {
  if (fromSystem) {
    writeLine(`<span style='color: yellow;'>[System] ${message}`)
    return;
  }
  if (currentEncryptionKey) {
    postData("/decrypt", { message: message, key: currentEncryptionKey })
      .then((data) => {
        writeLine(`<span style="color: yellow;">${username}:</span> ${data.message}`)
        _("#console").scrollBottom();
      })
    return
  }
  writeLine(`<span style="color: yellow;">${username}:</span> ${message}`)
  _("#console").scrollBottom();
})

socket.on("userDisconnect", (data) => {
  const user = data.username;
  const reason = data.reason;
  writeLine(`<span style="color: yellow">[System] ${user} disconnected/left. Reason: ${reason}</span>`)
})

socket.on("joinSuccess", (room) => {
  _(".commandLineText", true).forEach(ele => { ele.remove(); })
  writeLine(`<span style="color: green;">Joined room "${room}"</span>`)
  writeLine(`<span>Click <a style="color: white; text-decoration: underline; cursor: pointer;" href="">here</a> to leave.`)
  _("#consoleInput").show();
  _("#consoleInputEditable").focus();
  inRoom = true;
  _("#consoleInputUser").innerHTML = `${localUsername} (${room})>`
})

// Functions
if (localStorage.getItem("username") != null) {
  writeLine(`<span style="color: green">Welcome, ${localStorage.getItem("username")}!</span>`)
} else {
  writeLine(`<span style="color: green">Welcome!</span>`)
  writeLine(`<span style="color: yellow">To join rooms and chat use the command \`username -s {username}\`</span>`)
}

function writeLine(line) {
  const ele = document.createElement("p")
  ele.classList.add("commandLineText")
  ele.innerHTML = line;
  _("#consoleTexts").appendChild(ele);
}

_("#consoleInputEditable").addEventListener("keydown", (e) => {
  const keycode = e.keyCode;
  if (keycode == 13) {
    _("#console").scrollBottom();
    if (_("#consoleInputEditable").value == "" && !inRoom) {
      writeLine(`${localUsername}>`);
      return;
    }
    if (!inRoom) writeLine(`${localUsername}>${_("#consoleInputEditable").value}`);
    alzLine(_("#consoleInputEditable").value)
    _("#consoleInputEditable").value = ''
  }
})

function alzLine(command) {
  if (requireRefresh) return;
  if (waitingForKey) {
    currentEncryptionKey = command;
    writeLine(`<span style="color: green">Encryption key set! Joining...`)
    socket.emit("joinRoom", localUsername, currentRoom);
    waitingForKey = false;
    return;
  }
  if (inRoom) {
    if (command.replaceAll(" ", "") == "") return;
    if (calmDown) return;
    if (command.startsWith("/setEncrypted ")) {
      const args = command.split(" ")[1]
      if (args == "true") { postData("/roomSettingsEncrypt", { setEncrypted: true, room: currentRoom }); writeLine("You must leave to apply an encryption key.") }
      else if (args == "false") postData("/roomSettingsEncrypt", { setEncrypted: false, room: currentRoom })
      writeLine(`<span style="color: green">Settings applied...</span>`)
      const date = new Date();
      postData("/sendMessage", { message: `${localUsername} has set the encryption settings to \`${args}\`. Please ask them for the key.`, user: localUsername, time: `${date.getHours()}:${date.getMinutes()}`, isSystem: true })
      .then((data) => {
        if (data.limiter) {
          console.dir(data)
          calmDown = true;
          if (!document.body.contains(_(".calmDown"))) writeLine(`<span style="color: red;" class="calmDown">Please try again in a moment.</span>`)
          setTimeout(() => { calmDown = false; _(".calmDown").remove(); }, 5000);
        }
      })
      _("#consoleInputEditable").focus();
      return;
    }
    const date = new Date();
    if (currentEncryptionKey) {
      postData("/encrypt", { message: command, key: currentEncryptionKey })
        .then((data) => {
          postData("/sendMessage", { message: data.message, user: localUsername, time: `${date.getHours()}:${date.getMinutes()}` })
            .then((data2) => {
              if (data2.limiter) {
                calmDown = true;
                if (!document.body.contains(_(".calmDown"))) writeLine(`<span style="color: red;" class="calmDown">Calm down! You are sending too many messages at once!</span>`)
                setTimeout(() => { calmDown = false; _(".calmDown").remove(); }, 5000);
              }
            })
        })
      return;
    }
    //socket.emit("sendMessage", { message: command, user: localUsername, time: `${date.getHours()}:${date.getMinutes()}`})
    postData("/sendMessage", { message: command, user: localUsername, time: `${date.getHours()}:${date.getMinutes()}` })
      .then((data) => {
        if (data.limiter) {
          console.dir(data)
          calmDown = true;
          if (!document.body.contains(_(".calmDown"))) writeLine(`<span style="color: red;" class="calmDown">Calm down! You are sending too many messages at once!</span>`)
          setTimeout(() => { calmDown = false; _(".calmDown").remove(); }, 5000);
        }
      })
    return;
  }
  if (command == "username") {
    writeLine(`Username<br>----<br>-s | Sets the username<br>-g | Returns the username<br>-r | Resets the username`)
  } else if (command.startsWith("username -s")) {
    const args = command.split(" ")[2];
    if (!args) return;
    writeLine(`Username set to ${args}<br><span style="color: white;">Please <a style="cursor: pointer; text-decoration: underline; color: white;" href="">refresh</a> to apply!</span>`)
    requireRefresh = true;
    _("#consoleInput").remove();
    localStorage.setItem("username", args)
    _("#consoleInputUser").innerText = args + ">";
  } else if (command == "join") {
    writeLine(`Join<br>----<br>join &lt;room-name&gt;`)
  } else if (command.startsWith("join ")) {
    const args = command.replace("join ", "")
    if (!args) return;
    if (!localStorage.getItem("username")) {
      writeLine(`<span style="color: red">You must set a username before joining rooms!</span>`)
      return;
    }
    writeLine(`<span style="color: yellow;">Trying to join room "${args}"...</span>`)
    _("#consoleInput").hide();
    postData('/checkRoom', { room: args, user: localUsername })
      .then((data) => {
        if (data.roomEncrypted) {
          writeLine(`<span style="color: red">This room is encrypted! Please type the key:`)
          waitingForKey = true;
          currentRoom = args;
          _("#consoleInput").show();
          _("#consoleInputEditable").focus();
        }
        else {
          writeLine(`<span style="color: yellow;">Trying to join...`)
          currentRoom = args;
          socket.emit("joinRoom", localUsername, args);
        }
      });
  } else if (command.startsWith("create -r ")) {
    const args = command.split(" ")[2];
    if (!args) return;
  } else if (command == "clear") {
    _(".commandLineText", true).forEach(ele => {
      ele.remove();
    })
  } else if (command == "help" || command == "commands") {
    // send command list
    console.warn("Command list doesn\'t exist yet!")
  } else if (command.startsWith("username -g")) {
    writeLine(`Current username: ${localStorage.getItem("username")} Is guest: ${localStorage.getItem("isGuest") || false}`)
  } else if (command.startsWith("username -r")) {
    localStorage.removeItem("username");
    writeLine(`Username reset.`)
    window.location = ''
  } else if (command.startsWith("send ")) {
    const args = command.split(" ")[1]
    postData("/sendMessage", { username: localUsername, message: args })
      .then((data) => {
        console.dir(data)
      })
  } else if (command.startsWith("encryption -s ")) {
    const args = command.replace("encryption -s ");
    if (!args) return;
    currentEncryptionKey = args;
  }
  else {
    if (inRoom) return;
    writeLine(`<span style="color: red;">'${command}' is not a recognized command.</span>`)
  }
}

async function postData(url = '', data = {}) {
  const response = await fetch(url, {
    method: 'POST',
    body: JSON.stringify(data),
    headers: {
      'Content-Type': 'application/json'
    },
  });
  return response.json();
}

document.addEventListener('beforeunload', (e) => {
  e.preventDefault();
  socket.emit("disconnectLeave", localUsername)
})

const encrypt = async (data, key) => {
  const encoded = encode(data)
  const iv = generateIv()
  const cipher = await window.crypto.subtle.encrypt({
    name: 'AES-GCM',
    iv: iv,
  }, key, encoded)
  return {
    cipher,
    iv,
  }
}

const encode = (data) => {
  const encoder = new TextEncoder()
  return encoder.encode(data)
}

const generateKey = async () => {
  return window.crypto.subtle.generateKey({
    name: 'AES-GCM',
    length: 256,
  }, true, ['encrypt', 'decrypt'])
}
generateKey().then((data) => {
  console.log(data.toString())
})