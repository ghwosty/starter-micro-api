const express = require('express');
const http = require("http");
const app = express();
const path = require('path');
const router = express.Router();
const sqlite3 = require('sqlite3').verbose();
const fs = require('fs');
const server = http.createServer(app);
const { Server } = require("socket.io");
const rateLimit = require('express-rate-limit')
const io = new Server(server);
const CryptoJS = require("crypto-js");

//const db = new sqlite3.Database('./rooms.db', sqlite3.OPEN_READWRITE);

var rooms = [];
var usernames = [];
var encryptedRooms = [];

const messageLimiter = rateLimit({
  windowMs: 5000, // 5 seconds
  max: 6, // Limit each IP to 100 requests per `window` (here, per 15 minutes)
  standardHeaders: true, // Return rate limit info in the `RateLimit-*` headers
  legacyHeaders: false, // Disable the `X-RateLimit-*` headers
  statusCode: 200,
  message: {
    limiter: true,
    type: "error",
    message: "Too many messages!"
  }
})

app.use(express.static(__dirname + '/static'));
app.use(express.json());
app.set('socketio', io);
app.use('/sendMessage', messageLimiter);

app.get('/', (req, res) => {
  res.sendFile(path.join(__dirname + '/html/index.html'));
});

app.get('/consoleapp', (req, res) => {
  setTimeout(() => { res.sendFile(path.join(__dirname + '/html/consolechat.html')) }, 500);
})

app.get("/regularchat", (req, res) => {
  res.sendFile(path.join(__dirname + '/html/regularChat.html'))
  //setTimeout(() => { res.sendFile(path.join(__dirname + '/html/regularChat.html')) }, 500);
})

app.post('/checkRoom', (req, res) => {
  if (encryptedRooms.includes(req.body.room)) {
    res.send({
      roomEncrypted: true,
    })
  } else {
    res.send({
      roomEncrypted: false,
    })
  }
})

app.post("/roomSettingsEncrypt", (req, res) => {
  console.log("Setting room settings")
  if (req.body.setEncrypted) {
    encryptedRooms.push(req.body.room);
    res.send({
      settingsApplied: true,
    });
  } else {
    for (let i = 0; i < encryptedRooms.length; i++) {
      if (encryptedRooms[i] == req.body.room) {
        delete encryptedRooms[i];
        res.send({
          settingsApplied: true,
        });
      }
    }
  }
})

app.post('/checkUsername', (req, res) => {
  const username = req.body.username;
  if (usernames.includes(username)) res.send({ usernameExists: true })
  else res.send({ usernameExists: false })
})

app.post('/sendMessage', (req, res) => {
  if (req.body.message.includes(`<span id=""inputPlaceholder"`)) return;
  const username = req.body.user;
  const message = req.body.message.sanitize();
  const time = req.body.time;
  const isSystem = req.body.isSystem;
  const id = req.body.id;
  if (message.replaceAll(/\s/g, "").replaceAll("\n", "") == "" || !time || !username) return;
  if (isSystem) {
    io.to(rooms[username]).emit("recieve_message", message, username, true);
    res.status(200).json({ messageSent: true });
    return
  }
  io.to(rooms[username]).emit("recieve_message", message, username, false, id);
  res.status(200).json({ messageSent: true });
})

String.prototype.sanitize = function() {
  return this
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;")
    .replace(/'/g, "&#039;");
}

app.post("/encrypt", (req, res) => {
  var ciphertext = CryptoJS.AES.encrypt(req.body.message, req.body.key).toString();
  res.send({
    message: ciphertext,
  })
})

app.post("/decrypt", (req, res) => {
  var bytes = CryptoJS.AES.decrypt(req.body.message, req.body.key);
  var originalText = bytes.toString(CryptoJS.enc.Utf8);
  res.send({
    message: originalText,
  })
})

app.all('*', (req, res) => {
  res.sendFile(path.join(__dirname + '/html/404.html'));
})

io.on('connection', (socket) => {
  socket.on("joinRoom", (username, room) => {
    if (!username || !room) return;
    rooms[username] = room;
    usernames[socket.id] = username;
    socket.leaveAll();
    socket.join(room);
    socket.emit("joinSuccess", room)
    io.to(rooms[username]).emit("recieve_join", username, io.sockets.adapter.rooms.get(room).size)
  })

  socket.on("disconnectLeave", (username) => {
    console.log(username + " disconnected");
    io.to(rooms[username]).emit("userDisconnect", { user: username, reason: "page-leave" })
    delete rooms[username];
    socket.leaveAll();
  })

  socket.on("disconnect", () => {
    if (io.sockets.adapter.rooms.get(rooms[usernames[socket.id]]) == null) return;
    io.to(rooms[usernames[socket.id]]).emit("recieve_join", usernames[socket.id], io.sockets.adapter.rooms.get(rooms[usernames[socket.id]]).size, true)
    delete rooms[usernames[socket.id]];
    delete usernames[socket.id];
  })
});

server.listen(process.env.port || 3000, () => {
  const date = new Date();
  console.log(`[${date.getHours()}:${date.getMinutes()}] Running at Port ${process.env.port || 3000}`);
});

